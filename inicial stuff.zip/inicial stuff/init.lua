minetest.register_on_newplayer(function(player)
	print("[minimal] giving initial stuff to player")
	player:get_inventory():add_item('main','blocksfnaf:axe_fnaf')
	      
end)
